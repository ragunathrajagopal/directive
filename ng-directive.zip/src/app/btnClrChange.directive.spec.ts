/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { BtnClrChangeDirective } from './btnClrChange.directive';

describe('Directive: BtnClrChange', () => {
  it('should create an instance', () => {
    const directive = new BtnClrChangeDirective();
    expect(directive).toBeTruthy();
  });
});
